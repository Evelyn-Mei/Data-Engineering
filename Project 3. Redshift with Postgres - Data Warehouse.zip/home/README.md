# Sparkify Data Pipeline
## Description
Sparkify is a music streaming app. The company needs constant monitoring if its usage, based on which the product team can make incremental improvements to the user experience.
The pipeline loads data from Amazon S3,  copies into a staging table in Redshift, then transforms data into a set of dimension tables where the engineers and product teams can use to discover usage patterns.
## The Files
### create_tables.py
This file creates a Redshift database, drops any tables if exists, and creates a new set of tables. The tables are defined in the sql_queries.py files.

### sql_queries.py
This file contains PostgreSql queries to create, insert and drop the tables needed for this project. These tables are staging_songs, staging_events, songplays, users, artists, songs,  time

### etl.py
This file builds the data pipeline. 
It first executes functions to read song_data and log_data from s3 and populate the respective staging tables. 
Then, it inserts data from teh staging tables into the fact table and dimension tables

## Usage
First create the database and the tables

```bash
python create_tables.py
```
Then ingest data into the staging table and dimension tables
```bash
python etl.py
```


    

    
 