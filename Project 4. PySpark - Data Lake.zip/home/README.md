# Sparkify Data Lake
## Description
Sparkify is a music streaming app. The company needs constant monitoring if its usage, based on which the product team can make incremental improvements to the use experience.
This ETL pipeline extracts data from S3, processes them using Spark, and loads the data back into S3 as a set of dimensional tables. This will allow the analytics team to continue finding insights in what songs the users are listening to.

## The Files

### etl.py
This file builds the data pipeline through two main functions: process_song_data and process_log_data.
It extracts data from S3 via the 'input_data' path, then creates dimension tables, namely song_table, artist_table, user_table, time_table and songplays_table. Then writes them  to the specificed 'output_data' path.
### dl.cfg
This file specifies the AWS_ACCESS_KEY_ID, and AWS_SECRET_ACCESS_KEY for accessing the output S3 bucket

### my etl.ipynb
This file is a draft that I wrote to develop and test the process_song_data pipeline step by step

### my etl-log.ipynb
This file is a draft that I wrote to develop and test the process_logg_data pipeline step by step


## Usage
First specify log in credentials in dl.cfg
Then run the pipeline
```bash
python etl.py


    

    
 