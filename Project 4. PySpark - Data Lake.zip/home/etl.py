import configparser
from datetime import datetime
import os
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.functions import udf, col
from pyspark.sql.functions import year, month, dayofmonth, hour, weekofyear, date_format
from pyspark.sql.types import StructType as R, StructField as Fld, DoubleType as Dbl, StringType as Str, IntegerType as Int, DateType as Date, StringType as Str, TimestampType

config = configparser.ConfigParser()
#config.read('dl.cfg')

#os.environ['AWS_ACCESS_KEY_ID']=config['AWS_ACCESS_KEY_ID']
#os.environ['AWS_SECRET_ACCESS_KEY']=config['AWS_SECRET_ACCESS_KEY']

"""
Description: This function creates a spark session

Arguments:
    None
Returns:
    spark session
"""
def create_spark_session():
    spark = SparkSession \
        .builder \
        .config("spark.jars.packages", "org.apache.hadoop:hadoop-aws:2.7.0") \
        .getOrCreate()
    return spark

"""
Description: extracts song data from input_data,processes it, create 2 dimension tables - song and artist, then  writes them to output_data path

Arguments:
    spark:the spark session
    input_data:input data path
    output_data: output data path
Returns:
    None
"""
def process_song_data(spark, input_data, output_data):

    # get filepath to song data file
    song_input_data = input_data + 'song_data/*/*/*/*.json'
    #song_input_data = "data/more/song_data/A/A/A/TRAAABD128F429CF47.json"
    
    #or data/more/song-data/*.json"
    song_output_data=output_data+"song_data"
    
    # read song data file
    songSchema = R([
        Fld("num_songs",Int()),
        Fld("artist_id",Str()),
        Fld("artist_latitude",Dbl()),
        Fld("artist_longitude",Dbl()),
        Fld("artist_location",Str()),
        Fld("artist_name",Str()),
        Fld("song_id",Str()),
        Fld("title",Str()),
        Fld("duration",Dbl()),
        Fld("year",Int())
    ])
    df = spark.read.format("json").load(song_input_data, schema=songSchema)
    
    # write songs table to parquet files partitioned by year and artist
    df.createOrReplaceTempView("songs")
    songs_table = spark.sql("""
        SELECT     
            DISTINCT song_id,
            title,
            artist_id,
            year,
            duration
        FROM songs
    """)
    # write songs table to a parquet file
    songs_table.write.partitionBy("year", "artist_id").parquet(song_output_data + "-song_table")

    # extract columns to create artists table
    artists_table = spark.sql("""
        SELECT  
            DISTINCT artist_id,
            num_songs,
            artist_latitude,
            artist_longitude,
            artist_location,
            artist_name,
            song_id,
            title,
            duration,
            year
        FROM songs  

    """)
    
    # write artists table to parquet files
    artists_table.write.parquet(song_output_data+"-artist_table")

"""
Description: extracts log data from input_data,processes it, joins with song table,  then create 3 dimension tables - songplay, user and time, then writes them to output_data path

Arguments:
    spark:the spark session
    input_data:input data path
    output_data: output data path
Returns:
    None
"""
def process_log_data(spark, input_data, output_data):
    # get filepath to log data file
    log_input_data = input_data+"log_data"
    log_output_data=output_data+"log_data"
    
    # read log data file
    logSchema = R([
    Fld("artist",Str()),
    Fld("auth",Str()),
    Fld("firstName",Str()),
    Fld("gender",Str()),
    Fld("itemInSession",Dbl()),
    Fld("lastName",Str()),
    Fld("artist_latitude",Dbl()),
    Fld("length",Dbl()),
    Fld("level",Str()),
    Fld("location",Str()),
    Fld("method",Str()),
    Fld("page",Str()),
    Fld("registration",Dbl()),
    Fld("sessionId",Str()),
    Fld("song",Str()),
    Fld("status",Dbl()),
    Fld("ts",Dbl()),
    Fld("userAgent",Str()),
    Fld("userId",Str())
    
])
    df = spark.read.format("json").load(log_input_data, schema=logSchema)
    
    # filter by actions for song plays
    
    df_filtered=df[df['page']=="NextSong"]

    # extract columns for users table  
    df_filtered.createOrReplaceTempView("logs")
    users_table = spark.sql("""
    SELECT  
        DISTINCT userId AS user_id,
        firstName AS first_name,
        lastName AS last_name, 
        gender, 
        level
    FROM logs  

    """)
    
    # write users table to parquet files
    #define output location
    users_table.write.parquet(log_output_data+"-users_table")

    # create timestamp column from original timestamp column
    get_timestamp = udf(lambda x: x/1000, Dbl())
    df_filtered = df_filtered.withColumn('start_time', get_timestamp('ts'))

    
    # create datetime column from original timestamp column
    df_with_time = df_filtered.withColumn("TimestampType",F.to_timestamp(df_filtered["start_time"]))
    df_with_time = df_with_time.withColumn("hour",F.hour(df_with_time["TimestampType"]))
    df_with_time = df_with_time.withColumn("day",F.dayofmonth(df_with_time["TimestampType"]))
    df_with_time = df_with_time.withColumn("week",F.weekofyear(df_with_time["TimestampType"]))
    df_with_time = df_with_time.withColumn("month",F.month(df_with_time["TimestampType"]))
    df_with_time = df_with_time.withColumn("year",F.year(df_with_time["TimestampType"]))
    df_with_time = df_with_time.withColumn("weekday",F.dayofweek(df_with_time["TimestampType"]))

    # extract columns to create time table
     
    df_with_time.createOrReplaceTempView("logs_with_time")
    time_table = spark.sql("""
        SELECT  
            TimestampType AS start_time,
            hour,
            day,
            week,
            month
            year, 
            weekday
        FROM logs_with_time  

    """)
   
    
    # write time table to parquet files partitioned by year and month
    time_table.write.parquet(log_output_data+"-time_table")

    # read in song data to use for songplays table
    song_df = spark.read.parquet(output_data +"/song_data"+ "-song_table")
    song_df.createOrReplaceTempView("songs")
    
    #generate a new column on the  logs to hold the unique id
    df_with_time=df_with_time.withColumn("id", F.monotonically_increasing_id() + 123)
    df_with_time.createOrReplaceTempView("logs")
    # extract columns from joined song and log datasets to create songplays table 
    songplays_table = spark.sql("""
        SELECT
        logs.id AS songplay_id , 
        logs.start_time AS start_time, 
        logs.userId AS user_id, 
        logs.level AS level, 
        songs.song_id AS song_id, 
        songs.artist_id, 
        logs.sessionId AS session_id, 
        logs.location, 
        logs.userAgent AS user_agent,
        logs.year,
        logs.month
        FROM logs,songs
        WHERE songs.title = logs.song


    """)

    
    # write songplays table to parquet files partitioned by year and month
    songplays_table.write.partitionBy("year", "month").parquet(log_output_data + "-songplays_table")


def main():
    spark = create_spark_session()
    input_data = "s3a://udacity-dend/"
    #input_data = "data/more/"
    output_data = "s3://evelyn-66-demo/"
    #output_data="output/output_8/"
    
    process_song_data(spark, input_data, output_data)    
    process_log_data(spark, input_data, output_data)


if __name__ == "__main__":
    main()
