# Sparkify Data Pipeline
## Description
Sparkify is a music streaming app. The company needs constant monitoring if its usage, based on which the product team can make incremental improvements to the use experience.
The pipeline takes in songplay records, and combines that info with user, artist, and song data to render the full App usage patterns.

## The Files
### create_tables.py
This file creates a postgresql database, drops any tables if exists, and creates a new set of tables. The tables are defined in  the sql_queries.py files.

### sql_queries.py
This file contains postgresql queries to create, insert and drop the tables needed for this project. These tables are songplay, user, artist, song,  time

### etl.py
This file builds the data pipeline. It executes functions to read files in the filepath (either 'data/song_data' or 'data/log_data')
and populate the respective tables. It also printe the number of files found and processed. 

## Usage
First create the database and the tables
```bash
python create_tables.py
```
Then ingest data
```bash
python etl.py
```


    

    
 