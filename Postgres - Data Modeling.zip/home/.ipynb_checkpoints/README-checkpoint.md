<h1>Sparkify Data Pipeline</h1>
<h2>The Rationale</h2>
<p>Sparkify is a music streaming app. The company needs constant monitoring if its usage, based on which the product team can make incremental improvements to the use experience.</p>
<h2>The ETL Pipeline</h2>
<p>The pipeline takes in songplay records, and combines that info with user, artist, and song data to render the full App usage patterns.  <p>

    def process_log_file(cur, filepath):
"""
Description: This function can be used to read the file in the filepath (data/log_data)
to get the user and time info and used to populate the users and time dim tables.

Arguments:
    cur: the cursor object.
    filepath: log data file path.

Returns:
    None
"""
    
 def process_song_file(cur, filepath):
"""
Description: This function can be used to read the file in the filepath (data/song_data)
to get the song and artist info and used to populate the songs and artist dim tables.

Arguments:
    cur: the cursor object.
    filepath: song data file path.

Returns:
    None
"""
    
    
    def process_data(cur, conn, filepath, func):
"""
Description: This function can be used to read the file in the filepath (either 'data/song_data' or 'data/log_data')
and calls the process_song_file and process_log_file fuctions to populate the respective tables. It also printe the number of files found and processed.
Arguments:
    cur: the cursor object.
    conn:connection
    filepath: data file path.
    func: either process_song_file or process_log_file fuctions

Returns:
    None
"""
    